import { useState, useEffect, useRef } from "react";
import { sGet, sSet } from "./storage.js";

const KEY_EMPLOYEES = "emp_list";
const KEY_RECORDS   = "absen_records";
const ADMIN_PIN     = "1234";

const todayStr = () => new Date().toISOString().split("T")[0];
const fmtTime  = iso => iso ? new Date(iso).toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" }) : "–";
const fmtDate  = d => new Date(d).toLocaleDateString("id-ID", { weekday: "long", day: "numeric", month: "long", year: "numeric" });

const AVATAR_COLORS = ["#2563eb","#7c3aed","#db2777","#059669","#d97706","#dc2626","#0891b2","#0d9488"];
const avatarColor = id => AVATAR_COLORS[Math.abs(String(id).split("").reduce((a,c)=>a+c.charCodeAt(0),0)) % AVATAR_COLORS.length];

const DEFAULT_EMPLOYEES = [
  { id: "e1", name: "Budi Santoso",  jabatan: "Manager" },
  { id: "e2", name: "Siti Rahayu",   jabatan: "Staff Admin" },
  { id: "e3", name: "Andi Wijaya",   jabatan: "Developer" },
];

/* ══════════════════════════════════════════
   ROOT
══════════════════════════════════════════ */
export default function App() {
  const [view,        setView]        = useState("select");
  const [selectedEmp, setSelectedEmp] = useState(null);
  const [employees,   setEmployees]   = useState([]);
  const [records,     setRecords]     = useState({});
  const [loading,     setLoading]     = useState(true);
  const [adminPin,    setAdminPin]    = useState("");
  const [pinError,    setPinError]    = useState(false);

  useEffect(() => {
    (async () => {
      let emps = await sGet(KEY_EMPLOYEES);
      if (!emps) { emps = DEFAULT_EMPLOYEES; await sSet(KEY_EMPLOYEES, emps); }
      const recs = await sGet(KEY_RECORDS) || {};
      setEmployees(emps);
      setRecords(recs);
      setLoading(false);
    })();
  }, []);

  const saveRecords = async updated => { setRecords(updated); await sSet(KEY_RECORDS, updated); };
  const saveEmployees = async updated => { setEmployees(updated); await sSet(KEY_EMPLOYEES, updated); };
  const refreshRecords = async () => { const recs = await sGet(KEY_RECORDS) || {}; setRecords(recs); };

  if (loading) return <Splash />;

  if (view === "select")
    return <SelectScreen employees={employees}
      onSelectEmp={e => { setSelectedEmp(e); setView("employee"); }}
      onAdminClick={() => setView("admin-login")} />;

  if (view === "employee" && selectedEmp)
    return <EmployeeScreen emp={selectedEmp} records={records}
      saveRecords={saveRecords} onBack={() => setView("select")} />;

  if (view === "admin-login")
    return <PinScreen pin={adminPin} setPin={setAdminPin} error={pinError}
      onSubmit={() => {
        if (adminPin === ADMIN_PIN) { setPinError(false); setAdminPin(""); setView("admin"); }
        else setPinError(true);
      }}
      onBack={() => { setAdminPin(""); setPinError(false); setView("select"); }} />;

  if (view === "admin")
    return <AdminScreen employees={employees} records={records}
      refreshRecords={refreshRecords} saveEmployees={saveEmployees}
      onBack={() => setView("select")} />;

  return null;
}

/* ══════════════════════════════════════════
   SPLASH
══════════════════════════════════════════ */
function Splash() {
  return (
    <div style={{ minHeight:"100vh", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", background:"#f0f4f8" }}>
      <div style={{ fontSize:52 }}>🏢</div>
      <div style={{ fontFamily:"Georgia,serif", fontSize:24, fontWeight:700, color:"#1e3a5f", marginTop:12 }}>Hadir.app</div>
      <div style={{ color:"#94a3b8", fontSize:14, marginTop:8 }}>Memuat data…</div>
    </div>
  );
}

/* ══════════════════════════════════════════
   SELECT SCREEN
══════════════════════════════════════════ */
function SelectScreen({ employees, onSelectEmp, onAdminClick }) {
  const [search, setSearch] = useState("");
  const filtered = employees.filter(e => e.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div style={S.page}>
      <div style={S.header}>
        <div>
          <div style={S.eyebrow}>Sistem Absensi Digital</div>
          <div style={S.title}>Hadir<span style={{ color:"#38bdf8" }}>.app</span></div>
          <div style={S.sub}>{fmtDate(new Date())}</div>
        </div>
        <Clock />
      </div>

      <div style={S.body}>
        <p style={{ textAlign:"center", color:"#64748b", marginBottom:20, fontSize:15 }}>
          Pilih nama Anda untuk absen
        </p>

        <input placeholder="🔍  Cari nama…" value={search}
          onChange={e => setSearch(e.target.value)} style={S.input} />

        <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
          {filtered.map(emp => (
            <button key={emp.id} onClick={() => onSelectEmp(emp)} style={S.empCard}>
              <Avatar name={emp.name} id={emp.id} size={44} />
              <div>
                <div style={{ fontWeight:700, color:"#1e293b", fontSize:16 }}>{emp.name}</div>
                <div style={{ fontSize:13, color:"#94a3b8" }}>{emp.jabatan}</div>
              </div>
              <div style={{ marginLeft:"auto", color:"#cbd5e1", fontSize:22 }}>›</div>
            </button>
          ))}
          {filtered.length === 0 && (
            <div style={{ textAlign:"center", color:"#94a3b8", padding:28 }}>Karyawan tidak ditemukan</div>
          )}
        </div>

        <button onClick={onAdminClick} style={S.adminBtn}>🔐 Masuk sebagai Admin</button>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════
   EMPLOYEE SCREEN
══════════════════════════════════════════ */
function EmployeeScreen({ emp, records, saveRecords, onBack }) {
  const today = todayStr();
  const rec   = records?.[today]?.[emp.id] || {};

  const [phase,    setPhase]    = useState("idle");
  const [action,   setAction]   = useState(null);
  const [photo,    setPhoto]    = useState(null);
  const [location, setLocation] = useState(null);
  const [locErr,   setLocErr]   = useState(null);
  const [toast,    setToast]    = useState(null);

  const videoRef  = useRef();
  const canvasRef = useRef();
  const streamRef = useRef();

  const canMasuk  = !rec.masuk;
  const canPulang = !!rec.masuk && !rec.pulang;
  const status    = !rec.masuk ? "Belum Absen" : !rec.pulang ? "Sudah Masuk" : "Sudah Pulang";

  const stopCamera = () => {
    streamRef.current?.getTracks().forEach(t => t.stop());
    streamRef.current = null;
  };

  const startCamera = async act => {
    setAction(act); setPhoto(null); setLocation(null); setLocErr(null); setPhase("camera");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" }, audio: false });
      streamRef.current = stream;
      if (videoRef.current) videoRef.current.srcObject = stream;
    } catch {
      setPhase("error");
      setToast({ msg: "❌ Izin kamera ditolak. Cek pengaturan browser.", type: "error" });
    }
  };

  const capture = async () => {
    const video = videoRef.current, canvas = canvasRef.current;
    if (!video || !canvas) return;
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    canvas.getContext("2d").drawImage(video, 0, 0);
    const dataUrl = canvas.toDataURL("image/jpeg", 0.72);
    setPhoto(dataUrl);
    stopCamera();
    setPhase("processing");

    if (!navigator.geolocation) { setLocErr("GPS tidak tersedia di browser ini"); setPhase("confirm"); return; }
    navigator.geolocation.getCurrentPosition(
      pos => {
        setLocation({ lat: pos.coords.latitude.toFixed(6), lng: pos.coords.longitude.toFixed(6), acc: Math.round(pos.coords.accuracy) });
        setPhase("confirm");
      },
      err => { setLocErr("Izin lokasi ditolak — " + err.message); setPhase("confirm"); },
      { enableHighAccuracy: true, timeout: 12000 }
    );
  };

  const submit = async () => {
    setPhase("saving");
    const entry = { time: new Date().toISOString(), photo, location, locErr: locErr || null };
    const updated = {
      ...records,
      [today]: { ...(records[today] || {}), [emp.id]: { ...rec, [action]: entry } }
    };
    await saveRecords(updated);
    setPhase("done");
    setToast({ msg: action === "masuk" ? "✅ Absen masuk berhasil!" : "🏠 Absen pulang berhasil!", type: "success" });
  };

  const cancel = () => { stopCamera(); setPhase("idle"); setPhoto(null); setLocation(null); };

  return (
    <div style={S.page}>
      <div style={S.header}>
        <button onClick={() => { stopCamera(); onBack(); }} style={S.backBtn}>‹ Kembali</button>
        <div style={{ textAlign:"right" }}>
          <div style={S.title}>Hadir<span style={{ color:"#38bdf8" }}>.app</span></div>
          <div style={S.sub}>{fmtDate(new Date())}</div>
        </div>
      </div>

      <div style={S.body}>
        {/* Profil */}
        <div style={{ background:"white", borderRadius:14, padding:"14px 16px", display:"flex", alignItems:"center", gap:14, boxShadow:"0 1px 6px rgba(0,0,0,.07)", marginBottom:14 }}>
          <Avatar name={emp.name} id={emp.id} size={52} />
          <div>
            <div style={{ fontWeight:800, fontSize:18, color:"#1e293b" }}>{emp.name}</div>
            <div style={{ fontSize:13, color:"#94a3b8" }}>{emp.jabatan}</div>
          </div>
          <div style={{ marginLeft:"auto" }}><StatusPill status={status} /></div>
        </div>

        {/* Timeline */}
        <div style={{ background:"white", borderRadius:14, padding:"12px 16px", boxShadow:"0 1px 6px rgba(0,0,0,.07)", marginBottom:16 }}>
          {[["Masuk", rec.masuk, "#10b981"], ["Pulang", rec.pulang, "#3b82f6"]].map(([label, data, color]) => (
            <div key={label} style={{ display:"flex", alignItems:"center", gap:10, padding:"8px 0", borderBottom: label==="Masuk" ? "1px solid #f1f5f9":"none" }}>
              <div style={{ width:8, height:8, borderRadius:"50%", background: data ? color : "#e2e8f0" }} />
              <div style={{ fontSize:13, color:"#64748b", width:50 }}>{label}</div>
              <div style={{ fontWeight:700, color:"#1e293b", fontSize:14 }}>
                {data ? fmtTime(data.time) : <span style={{ color:"#cbd5e1", fontWeight:400 }}>Belum</span>}
              </div>
              {data?.location && <div style={{ fontSize:11, color:"#94a3b8", marginLeft:"auto" }}>📍 GPS ✓</div>}
            </div>
          ))}
        </div>

        {/* Idle — tombol */}
        {phase === "idle" && (
          <div style={{ display:"flex", gap:12 }}>
            {[
              { label:"📷 Absen Masuk", color:"#2563eb", disabled: !canMasuk, act:"masuk" },
              { label:"📷 Absen Pulang", color:"#10b981", disabled: !canPulang, act:"pulang" },
            ].map(({ label, color, disabled, act }) => (
              <button key={act} disabled={disabled} onClick={() => startCamera(act)} style={{
                flex:1, padding:"16px 0", borderRadius:14, border:"none",
                background: disabled ? "#e2e8f0" : color,
                color: disabled ? "#94a3b8" : "white",
                fontWeight:800, fontSize:14, cursor: disabled ? "not-allowed" : "pointer",
                boxShadow: disabled ? "none" : `0 4px 14px ${color}55`,
                transition:"all .2s",
              }}>{label}</button>
            ))}
          </div>
        )}

        {/* Camera */}
        {phase === "camera" && (
          <div style={{ background:"white", borderRadius:16, padding:16, boxShadow:"0 2px 12px rgba(0,0,0,.1)" }}>
            <div style={{ position:"relative", borderRadius:14, overflow:"hidden", background:"#000", marginBottom:12 }}>
              <video ref={videoRef} autoPlay playsInline muted
                style={{ width:"100%", display:"block", maxHeight:300, objectFit:"cover" }} />
              {/* oval guide */}
              <div style={{
                position:"absolute", top:"50%", left:"50%", transform:"translate(-50%,-50%)",
                width:160, height:200, border:"3px solid rgba(255,255,255,.85)", borderRadius:"50%",
                pointerEvents:"none", boxShadow:"0 0 0 9999px rgba(0,0,0,.35)"
              }} />
            </div>
            <canvas ref={canvasRef} style={{ display:"none" }} />
            <div style={{ display:"flex", gap:10 }}>
              <button onClick={cancel} style={S.btnGray}>Batal</button>
              <button onClick={capture} style={{ ...S.btnBlue, flex:2 }}>📸 Ambil Foto</button>
            </div>
            <p style={{ textAlign:"center", fontSize:12, color:"#94a3b8", marginTop:8 }}>Posisikan wajah di dalam lingkaran</p>
          </div>
        )}

        {/* Processing GPS */}
        {phase === "processing" && (
          <div style={S.centerBox}>
            <div style={{ fontSize:40 }}>📡</div>
            <div style={{ fontWeight:700, color:"#1e3a5f", marginTop:10 }}>Mengambil lokasi GPS…</div>
            <div style={{ fontSize:13, color:"#94a3b8", marginTop:4 }}>Mohon tunggu sebentar</div>
          </div>
        )}

        {/* Confirm */}
        {phase === "confirm" && (
          <div style={{ background:"white", borderRadius:16, padding:16, boxShadow:"0 2px 12px rgba(0,0,0,.1)" }}>
            {photo && <img src={photo} alt="selfie"
              style={{ width:"100%", borderRadius:12, marginBottom:12, objectFit:"cover", maxHeight:240 }} />}
            <div style={{ display:"flex", gap:12, alignItems:"flex-start", background:"#f8fafc", borderRadius:10, padding:12, marginBottom:14 }}>
              {location
                ? <>
                    <span style={{ fontSize:20 }}>📍</span>
                    <div>
                      <div style={{ fontWeight:700, fontSize:13, color:"#1e293b" }}>Lokasi Terdeteksi</div>
                      <div style={{ fontSize:12, color:"#64748b" }}>Lat: {location.lat}</div>
                      <div style={{ fontSize:12, color:"#64748b" }}>Lng: {location.lng}</div>
                      <div style={{ fontSize:11, color:"#94a3b8" }}>Akurasi ±{location.acc}m</div>
                    </div>
                  </>
                : <>
                    <span style={{ fontSize:20 }}>⚠️</span>
                    <div style={{ fontSize:13, color:"#dc2626", fontWeight:600 }}>{locErr}</div>
                  </>
              }
            </div>
            <div style={{ display:"flex", gap:10 }}>
              <button onClick={cancel} style={S.btnGray}>Ulangi</button>
              <button onClick={submit}
                style={{ ...S.btnBlue, flex:2, background: action==="masuk" ? "#2563eb" : "#10b981" }}>
                ✓ Konfirmasi {action === "masuk" ? "Masuk" : "Pulang"}
              </button>
            </div>
          </div>
        )}

        {/* Saving */}
        {phase === "saving" && (
          <div style={S.centerBox}>
            <div style={{ fontSize:36 }}>⏳</div>
            <div style={{ fontWeight:700, color:"#1e3a5f", marginTop:10 }}>Menyimpan absensi…</div>
          </div>
        )}

        {/* Done */}
        {phase === "done" && (
          <div style={{ background:"#d1fae5", borderRadius:16, padding:28, textAlign:"center" }}>
            <div style={{ fontSize:52 }}>✅</div>
            <div style={{ fontWeight:800, fontSize:18, color:"#065f46", marginTop:8 }}>
              {action === "masuk" ? "Absen Masuk Tercatat!" : "Absen Pulang Tercatat!"}
            </div>
            <div style={{ fontSize:13, color:"#047857", marginTop:6 }}>
              {fmtTime(new Date().toISOString())} · {fmtDate(new Date())}
            </div>
            <button onClick={() => setPhase("idle")}
              style={{ ...S.btnBlue, background:"#059669", marginTop:18, padding:"12px 32px", width:"auto", display:"inline-block" }}>
              Selesai
            </button>
          </div>
        )}

        {/* Error */}
        {phase === "error" && (
          <div style={{ background:"#fee2e2", borderRadius:16, padding:24, textAlign:"center" }}>
            <div style={{ fontSize:40 }}>❌</div>
            <div style={{ fontWeight:700, color:"#dc2626", marginTop:8 }}>Kamera tidak bisa diakses</div>
            <div style={{ fontSize:13, color:"#ef4444", marginTop:6 }}>Pastikan izin kamera sudah diberikan di pengaturan browser.</div>
            <button onClick={() => setPhase("idle")} style={{ ...S.btnGray, marginTop:16, display:"inline-block", width:"auto", padding:"10px 24px" }}>
              Coba Lagi
            </button>
          </div>
        )}
      </div>

      {toast && <Toast msg={toast.msg} type={toast.type} onClose={() => setToast(null)} />}
    </div>
  );
}

/* ══════════════════════════════════════════
   PIN SCREEN
══════════════════════════════════════════ */
function PinScreen({ pin, setPin, error, onSubmit, onBack }) {
  return (
    <div style={{ minHeight:"100vh", display:"flex", alignItems:"center", justifyContent:"center", background:"#f0f4f8", padding:20 }}>
      <div style={{ width:"100%", maxWidth:360, background:"white", borderRadius:24, padding:32, boxShadow:"0 8px 40px rgba(0,0,0,.12)" }}>
        <div style={{ textAlign:"center", marginBottom:24 }}>
          <div style={{ fontSize:48 }}>🔐</div>
          <div style={{ fontWeight:800, fontSize:20, color:"#1e293b", marginTop:8 }}>Admin Login</div>
          <div style={{ fontSize:13, color:"#94a3b8", marginTop:4 }}>Masukkan PIN admin</div>
        </div>
        <input type="password" inputMode="numeric" maxLength={6}
          value={pin} onChange={e => setPin(e.target.value)}
          onKeyDown={e => e.key === "Enter" && onSubmit()}
          placeholder="••••" autoFocus
          style={{ ...S.input, textAlign:"center", fontSize:26, letterSpacing:10, marginBottom:8 }} />
        {error && <div style={{ color:"#dc2626", textAlign:"center", fontSize:13, marginBottom:10 }}>❌ PIN salah, coba lagi</div>}
        <button onClick={onSubmit} style={{ ...S.btnBlue, width:"100%", marginBottom:10, background:"#1e3a5f" }}>Masuk</button>
        <button onClick={onBack} style={{ ...S.btnGray, width:"100%" }}>Kembali</button>
        <div style={{ textAlign:"center", fontSize:11, color:"#cbd5e1", marginTop:14 }}>PIN default: 1234 · Ubah di App.jsx baris 7</div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════
   ADMIN SCREEN
══════════════════════════════════════════ */
function AdminScreen({ employees, records, refreshRecords, saveEmployees, onBack }) {
  const [tab,        setTab]        = useState("rekap");
  const [filterDate, setFilterDate] = useState(todayStr());
  const [modal,      setModal]      = useState(null);
  const [newName,    setNewName]    = useState("");
  const [newJob,     setNewJob]     = useState("");
  const [refreshing, setRefreshing] = useState(false);
  const [toast,      setToast]      = useState(null);

  const doRefresh = async () => {
    setRefreshing(true);
    await refreshRecords();
    setTimeout(() => setRefreshing(false), 600);
    setToast({ msg:"🔄 Data diperbarui", type:"success" });
  };

  const dayRecs = records?.[filterDate] || {};

  const rows = employees.map(emp => {
    const r = dayRecs[emp.id] || {};
    const masuk = r.masuk || null, pulang = r.pulang || null;
    let status = "Absen";
    if (masuk) { const h = new Date(masuk.time).getHours(); status = pulang ? "Pulang" : h >= 9 ? "Terlambat" : "Hadir"; }
    return { emp, masuk, pulang, status };
  });

  const counts = {
    hadir:     rows.filter(r => r.status === "Hadir" || r.status === "Pulang").length,
    terlambat: rows.filter(r => r.status === "Terlambat").length,
    absen:     rows.filter(r => r.status === "Absen").length,
  };

  const addEmp = async () => {
    if (!newName.trim()) return;
    const updated = [...employees, { id: "e" + Date.now(), name: newName.trim(), jabatan: newJob.trim() || "Staff" }];
    await saveEmployees(updated);
    setNewName(""); setNewJob("");
    setToast({ msg:"👤 Karyawan ditambahkan", type:"success" });
  };

  const removeEmp = async id => {
    await saveEmployees(employees.filter(e => e.id !== id));
    setModal(null);
    setToast({ msg:"🗑️ Karyawan dihapus", type:"success" });
  };

  return (
    <div style={S.page}>
      <div style={{ ...S.header, background:"linear-gradient(135deg,#0f172a,#1e3a5f)" }}>
        <div>
          <button onClick={onBack} style={S.backBtn}>‹ Keluar</button>
          <div style={{ ...S.title, marginTop:4 }}>Dashboard <span style={{ color:"#38bdf8" }}>Admin</span></div>
          <div style={S.sub}>{fmtDate(new Date())}</div>
        </div>
        <button onClick={doRefresh} style={{ background:"rgba(255,255,255,.15)", border:"none", color:"white", borderRadius:10, padding:"8px 14px", cursor:"pointer", fontWeight:700, fontSize:13 }}>
          {refreshing ? "…" : "🔄"} Refresh
        </button>
      </div>

      {/* Tabs */}
      <div style={{ display:"flex", background:"#f1f5f9", borderBottom:"1px solid #e2e8f0" }}>
        {[["rekap","📊 Rekap"],["foto","🖼️ Foto"],["karyawan","👥 Karyawan"]].map(([k,l]) => (
          <button key={k} onClick={() => setTab(k)} style={{
            flex:1, padding:"13px 0", border:"none", cursor:"pointer",
            fontWeight:700, fontSize:13, background: tab===k ? "white" : "transparent",
            color: tab===k ? "#2563eb" : "#64748b",
            borderBottom: tab===k ? "2px solid #2563eb" : "2px solid transparent",
          }}>{l}</button>
        ))}
      </div>

      <div style={S.body}>

        {/* ── REKAP ── */}
        {tab === "rekap" && <>
          <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:16, flexWrap:"wrap" }}>
            <input type="date" value={filterDate} onChange={e => setFilterDate(e.target.value)}
              style={{ ...S.input, width:"auto", padding:"8px 14px" }} />
            <div style={{ display:"flex", gap:8, flex:1, minWidth:180 }}>
              {[["Hadir",counts.hadir,"#10b981"],["Terlambat",counts.terlambat,"#f59e0b"],["Absen",counts.absen,"#ef4444"]].map(([l,v,c]) => (
                <div key={l} style={{ flex:1, background:"white", borderRadius:10, padding:"10px 6px", textAlign:"center", borderTop:`3px solid ${c}`, boxShadow:"0 1px 4px rgba(0,0,0,.06)" }}>
                  <div style={{ fontSize:20, fontWeight:800, color:c }}>{v}</div>
                  <div style={{ fontSize:11, color:"#94a3b8", fontWeight:600 }}>{l}</div>
                </div>
              ))}
            </div>
          </div>

          <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
            {rows.map(({ emp, masuk, pulang, status }) => (
              <div key={emp.id} style={{ background:"white", borderRadius:14, padding:"14px 16px", boxShadow:"0 1px 4px rgba(0,0,0,.06)" }}>
                <div style={{ display:"flex", alignItems:"center", gap:12, marginBottom: (masuk||pulang) ? 10 : 0 }}>
                  <Avatar name={emp.name} id={emp.id} size={40} />
                  <div style={{ flex:1 }}>
                    <div style={{ fontWeight:700, color:"#1e293b" }}>{emp.name}</div>
                    <div style={{ fontSize:12, color:"#94a3b8" }}>{emp.jabatan}</div>
                  </div>
                  <StatusPill status={status} />
                </div>
                {(masuk || pulang) && (
                  <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
                    {[["masuk",masuk,"#10b981"],["pulang",pulang,"#3b82f6"]].map(([key,entry,color]) => entry && (
                      <div key={key} style={{ display:"flex", alignItems:"center", gap:8, background:"#f8fafc", borderRadius:8, padding:"8px 12px", flex:1, minWidth:180, flexWrap:"wrap" }}>
                        <span style={{ color, fontWeight:700, fontSize:13, textTransform:"capitalize" }}>{key}</span>
                        <span style={{ fontSize:13 }}>{fmtTime(entry.time)}</span>
                        {entry.photo && <button onClick={() => setModal({ type:"photo", data:entry })} style={S.chipBtn}>📷 Foto</button>}
                        {entry.location && <button onClick={() => setModal({ type:"loc", data:entry.location })} style={S.chipBtn}>📍 Peta</button>}
                        {entry.locErr && <span style={{ fontSize:11, color:"#dc2626" }}>⚠️ No GPS</span>}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>}

        {/* ── FOTO ── */}
        {tab === "foto" && <>
          <div style={{ marginBottom:16 }}>
            <input type="date" value={filterDate} onChange={e => setFilterDate(e.target.value)}
              style={{ ...S.input, width:"auto", padding:"8px 14px" }} />
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
            {employees.map(emp => {
              const r = dayRecs[emp.id] || {};
              return (
                <div key={emp.id} style={{ background:"white", borderRadius:14, overflow:"hidden", boxShadow:"0 1px 6px rgba(0,0,0,.08)" }}>
                  <div style={{ padding:"10px 12px", borderBottom:"1px solid #f1f5f9" }}>
                    <div style={{ fontWeight:700, fontSize:13, color:"#1e293b" }}>{emp.name}</div>
                    <div style={{ fontSize:11, color:"#94a3b8" }}>{emp.jabatan}</div>
                  </div>
                  <div style={{ display:"flex" }}>
                    {["masuk","pulang"].map((act, i) => {
                      const entry = r[act];
                      return (
                        <div key={act} style={{ flex:1, padding:8, borderRight: i===0 ? "1px solid #f1f5f9" : "none" }}>
                          <div style={{ fontSize:10, fontWeight:700, color: act==="masuk"?"#10b981":"#3b82f6", marginBottom:4, textTransform:"uppercase" }}>{act}</div>
                          {entry?.photo
                            ? <img src={entry.photo} alt={act} onClick={() => setModal({ type:"photo", data:entry })}
                                style={{ width:"100%", aspectRatio:"1", objectFit:"cover", borderRadius:8, cursor:"pointer", border:"2px solid #e2e8f0" }} />
                            : <div style={{ width:"100%", aspectRatio:"1", background:"#f8fafc", borderRadius:8, display:"flex", alignItems:"center", justifyContent:"center", fontSize:22, color:"#e2e8f0" }}>?</div>
                          }
                          {entry?.time && <div style={{ fontSize:10, color:"#94a3b8", marginTop:4, textAlign:"center" }}>{fmtTime(entry.time)}</div>}
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </>}

        {/* ── KARYAWAN ── */}
        {tab === "karyawan" && <>
          <div style={{ background:"white", borderRadius:14, padding:18, marginBottom:16, boxShadow:"0 1px 4px rgba(0,0,0,.06)" }}>
            <div style={{ fontWeight:700, fontSize:14, color:"#1e293b", marginBottom:12 }}>➕ Tambah Karyawan</div>
            <input placeholder="Nama lengkap" value={newName} onChange={e => setNewName(e.target.value)} style={{ ...S.input, marginBottom:8 }} />
            <input placeholder="Jabatan" value={newJob}  onChange={e => setNewJob(e.target.value)}  style={{ ...S.input, marginBottom:10 }} />
            <button onClick={addEmp} style={{ ...S.btnBlue, width:"100%" }}>Tambah</button>
          </div>
          <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
            {employees.map(emp => (
              <div key={emp.id} style={{ background:"white", borderRadius:12, padding:"12px 16px", display:"flex", alignItems:"center", gap:12, boxShadow:"0 1px 4px rgba(0,0,0,.06)" }}>
                <Avatar name={emp.name} id={emp.id} size={40} />
                <div style={{ flex:1 }}>
                  <div style={{ fontWeight:700, color:"#1e293b" }}>{emp.name}</div>
                  <div style={{ fontSize:12, color:"#94a3b8" }}>{emp.jabatan}</div>
                </div>
                <button onClick={() => setModal({ type:"emp", data:emp })}
                  style={{ background:"#fee2e2", color:"#dc2626", border:"none", borderRadius:8, padding:"6px 12px", fontWeight:700, fontSize:12, cursor:"pointer" }}>
                  Hapus
                </button>
              </div>
            ))}
          </div>
        </>}
      </div>

      {/* Modals */}
      {modal && (
        <div onClick={() => setModal(null)} style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.5)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:999, padding:20 }}>
          <div onClick={e => e.stopPropagation()} style={{ background:"white", borderRadius:20, padding:24, maxWidth:380, width:"100%", boxShadow:"0 20px 60px rgba(0,0,0,.2)" }}>
            {modal.type === "photo" && <>
              <div style={{ fontWeight:700, fontSize:16, color:"#1e293b", marginBottom:12 }}>📷 Foto Selfie</div>
              <img src={modal.data.photo} alt="selfie" style={{ width:"100%", borderRadius:12, marginBottom:12 }} />
              {modal.data.location && <div style={{ fontSize:13, color:"#64748b" }}>📍 {modal.data.location.lat}, {modal.data.location.lng} (±{modal.data.location.acc}m)</div>}
              <div style={{ fontSize:12, color:"#94a3b8", marginTop:4 }}>{fmtTime(modal.data.time)}</div>
              <button onClick={() => setModal(null)} style={{ ...S.btnBlue, width:"100%", marginTop:14, background:"#1e3a5f" }}>Tutup</button>
            </>}
            {modal.type === "loc" && <>
              <div style={{ fontWeight:700, fontSize:16, color:"#1e293b", marginBottom:12 }}>📍 Lokasi Absen</div>
              <div style={{ background:"#f8fafc", borderRadius:12, padding:16, marginBottom:12 }}>
                <div style={{ fontSize:14, color:"#374151" }}>Latitude: <b>{modal.data.lat}</b></div>
                <div style={{ fontSize:14, color:"#374151" }}>Longitude: <b>{modal.data.lng}</b></div>
                <div style={{ fontSize:13, color:"#94a3b8" }}>Akurasi: ±{modal.data.acc}m</div>
              </div>
              <a href={`https://www.google.com/maps?q=${modal.data.lat},${modal.data.lng}`} target="_blank" rel="noreferrer"
                style={{ display:"block", textAlign:"center", background:"#2563eb", color:"white", padding:12, borderRadius:10, fontWeight:700, textDecoration:"none", marginBottom:10 }}>
                🗺️ Buka di Google Maps
              </a>
              <button onClick={() => setModal(null)} style={{ ...S.btnGray, width:"100%" }}>Tutup</button>
            </>}
            {modal.type === "emp" && <>
              <div style={{ textAlign:"center", marginBottom:16 }}>
                <div style={{ fontSize:40 }}>⚠️</div>
                <div style={{ fontWeight:800, fontSize:17, color:"#1e293b", marginTop:8 }}>Hapus Karyawan?</div>
                <div style={{ fontSize:14, color:"#64748b", marginTop:6 }}>Yakin hapus <b>{modal.data.name}</b>?</div>
              </div>
              <div style={{ display:"flex", gap:10 }}>
                <button onClick={() => setModal(null)} style={{ ...S.btnGray, flex:1 }}>Batal</button>
                <button onClick={() => removeEmp(modal.data.id)} style={{ ...S.btnBlue, flex:1, background:"#dc2626" }}>Hapus</button>
              </div>
            </>}
          </div>
        </div>
      )}

      {toast && <Toast msg={toast.msg} type={toast.type} onClose={() => setToast(null)} />}
    </div>
  );
}

/* ══════════════════════════════════════════
   SHARED COMPONENTS
══════════════════════════════════════════ */
function Avatar({ name, id, size = 44 }) {
  return (
    <div style={{
      width:size, height:size, borderRadius:"50%", background:avatarColor(id),
      display:"flex", alignItems:"center", justifyContent:"center",
      color:"white", fontWeight:800, fontSize:size*0.42, flexShrink:0,
    }}>{name[0]}</div>
  );
}

function StatusPill({ status }) {
  const m = {
    "Hadir":       { bg:"#d1fae5", c:"#065f46" },
    "Terlambat":   { bg:"#fef3c7", c:"#92400e" },
    "Pulang":      { bg:"#dbeafe", c:"#1e40af" },
    "Sudah Masuk": { bg:"#e0f2fe", c:"#0369a1" },
    "Sudah Pulang":{ bg:"#dbeafe", c:"#1e40af" },
    "Belum Absen": { bg:"#fee2e2", c:"#991b1b" },
    "Absen":       { bg:"#fee2e2", c:"#991b1b" },
  };
  const s = m[status] || m["Absen"];
  return <span style={{ background:s.bg, color:s.c, padding:"3px 10px", borderRadius:20, fontSize:12, fontWeight:700, whiteSpace:"nowrap" }}>{status}</span>;
}

function Clock() {
  const [t, setT] = useState(new Date());
  useEffect(() => { const i = setInterval(() => setT(new Date()), 1000); return () => clearInterval(i); }, []);
  return (
    <div style={{ background:"rgba(255,255,255,.15)", borderRadius:14, padding:"10px 16px", textAlign:"center", backdropFilter:"blur(10px)", flexShrink:0 }}>
      <div style={{ fontSize:22, fontWeight:800, letterSpacing:1, fontVariantNumeric:"tabular-nums" }}>
        {t.toLocaleTimeString("id-ID", { hour:"2-digit", minute:"2-digit", second:"2-digit" })}
      </div>
      <div style={{ fontSize:11, opacity:.75 }}>WIB</div>
    </div>
  );
}

function Toast({ msg, type, onClose }) {
  useEffect(() => { const t = setTimeout(onClose, 2800); return () => clearTimeout(t); }, []);
  return (
    <div style={{
      position:"fixed", bottom:28, left:"50%", transform:"translateX(-50%)",
      background: type==="error" ? "#dc2626" : "#1e3a5f",
      color:"white", padding:"12px 24px", borderRadius:14,
      fontWeight:600, fontSize:14, boxShadow:"0 8px 30px rgba(0,0,0,.2)",
      zIndex:1000, whiteSpace:"nowrap",
    }}>{msg}</div>
  );
}

/* ══════════════════════════════════════════
   STYLES
══════════════════════════════════════════ */
const S = {
  page:    { minHeight:"100vh", background:"#f0f4f8", display:"flex", flexDirection:"column", fontFamily:"'Segoe UI',system-ui,sans-serif" },
  header:  { background:"linear-gradient(135deg,#1e3a5f,#2563eb)", color:"white", padding:"20px 20px 16px", display:"flex", justifyContent:"space-between", alignItems:"flex-start", gap:12 },
  eyebrow: { fontSize:10, opacity:.7, letterSpacing:2, textTransform:"uppercase", marginBottom:4 },
  title:   { fontFamily:"Georgia,serif", fontSize:22, fontWeight:700 },
  sub:     { opacity:.8, fontSize:12, marginTop:2 },
  backBtn: { background:"rgba(255,255,255,.2)", border:"none", color:"white", padding:"5px 12px", borderRadius:8, cursor:"pointer", fontWeight:700, fontSize:14, marginBottom:4 },
  body:    { flex:1, padding:"18px 16px", maxWidth:680, width:"100%", margin:"0 auto", boxSizing:"border-box" },
  input:   { width:"100%", border:"2px solid #e2e8f0", borderRadius:12, padding:"11px 16px", fontSize:14, fontFamily:"inherit", outline:"none", boxSizing:"border-box", background:"white" },
  empCard: { background:"white", borderRadius:14, padding:"14px 16px", display:"flex", alignItems:"center", gap:14, border:"none", cursor:"pointer", boxShadow:"0 1px 6px rgba(0,0,0,.07)", textAlign:"left", width:"100%" },
  adminBtn:{ marginTop:28, width:"100%", padding:13, background:"#0f172a", color:"white", border:"none", borderRadius:12, fontWeight:700, fontSize:14, cursor:"pointer" },
  btnBlue: { padding:"12px 0", borderRadius:10, border:"none", background:"#2563eb", color:"white", fontWeight:700, fontSize:14, cursor:"pointer", width:"100%" },
  btnGray: { padding:"12px 0", borderRadius:10, border:"none", background:"#f1f5f9", color:"#374151", fontWeight:700, fontSize:14, cursor:"pointer", width:"100%" },
  centerBox:{ background:"white", borderRadius:16, padding:28, textAlign:"center", boxShadow:"0 1px 8px rgba(0,0,0,.08)" },
  chipBtn: { background:"white", border:"1px solid #e2e8f0", borderRadius:6, padding:"3px 8px", fontSize:12, cursor:"pointer", fontWeight:600, color:"#374151" },
};
