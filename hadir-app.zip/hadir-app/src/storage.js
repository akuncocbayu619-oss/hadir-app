// Shared storage using localStorage
// Data diakses dengan key yang sama dari semua browser/HP
// Gunakan backend nyata (Firebase/Supabase) untuk production multi-device

const PREFIX = "hadirapp_";

export async function sGet(key) {
  try {
    const raw = localStorage.getItem(PREFIX + key);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export async function sSet(key, val) {
  try {
    localStorage.setItem(PREFIX + key, JSON.stringify(val));
  } catch (e) {
    console.error("Storage error:", e);
  }
}

export async function sDel(key) {
  try {
    localStorage.removeItem(PREFIX + key);
  } catch {}
}
