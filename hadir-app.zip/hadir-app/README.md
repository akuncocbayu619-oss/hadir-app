# 🏢 Hadir.app — Sistem Absensi Digital

Aplikasi absensi digital dengan foto selfie dan lokasi GPS.

## Fitur
- 📷 Foto selfie saat absen masuk & pulang
- 📍 Deteksi lokasi GPS otomatis
- 🔐 Dashboard admin dengan PIN
- 📊 Rekap absensi per hari
- 🖼️ Galeri foto selfie karyawan
- 📱 Bisa dibuka dari HP masing-masing karyawan

## Cara Pakai
1. Karyawan buka link, pilih nama sendiri
2. Tap "Absen Masuk" → ambil selfie → lokasi otomatis terdeteksi
3. Admin buka link, tap "Masuk sebagai Admin", masukkan PIN

## PIN Admin
Default: `1234`
Ubah di: `src/App.jsx` baris 7 → `const ADMIN_PIN = "xxxx";`

## Development Lokal
```bash
npm install
npm run dev
```

## Deploy Ulang
Push ke branch `main` → otomatis ter-deploy via GitHub Actions.
